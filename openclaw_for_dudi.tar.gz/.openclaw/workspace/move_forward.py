import sys
import time
sys.path.insert(0, "/home/tamir/Desktop/openClaw Go2/unitree_sdk2_python")

from unitree_sdk2py.core.channel import ChannelFactoryInitialize
from unitree_sdk2py.go2.sport.sport_client import SportClient

if len(sys.argv) > 1:
    ChannelFactoryInitialize(0, sys.argv[1])
else:
    ChannelFactoryInitialize(0)

sport_client = SportClient()
sport_client.SetTimeout(10.0)
sport_client.Init()

# Move forward at 0.3 m/s
ret = sport_client.Move(0.3, 0, 0)
print(f"Move forward ret: {ret}")
time.sleep(1)

# Stop
ret = sport_client.StopMove()
print(f"StopMove ret: {ret}")
